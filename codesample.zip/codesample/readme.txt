Please put upload.php and upload.png somewhere and update corresponding url in draw.jsp(line 102) and clip.jsp(line 102).

This is a work around when initializing draw sdk for empty binder, the sdk will be empty.