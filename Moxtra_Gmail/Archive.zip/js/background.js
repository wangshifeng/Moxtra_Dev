//chrome.runtime.onMessage.addListener(function(response, sender, sendResponse){
//    alert(response)
//})
//
//var hosts = 'https://moxtra1.com';